<?php
include_once __DIR__.'/../includes/db.php';
class Products{
    private $pdo;
    public function getProduct(){
        $this->pdo=Database::connect();
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
        $sql='select * from products';
        $statement=$this->pdo->prepare($sql);
        $statement->execute();
        $products=$statement->fetchAll(PDO::FETCH_ASSOC);
        return $products;  

    }

    public function addProduct($type,$size,$name,$filename,$price,$description){
        $this->pdo=Database::connect();
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
        $sql='insert into products(category_id,name,price,description,status,image,created_date,updated_date) values(:id,:name,:price,:description,:status,:image,:created_date,:updated_date)';

        $statement=$this->pdo->prepare($sql);
        $statement->bindParam(":id",$type);
        $statement->bindParam(":name",$name);
        $statement->bindparam(":image",$filename);
        $statement->bindParam(":price",$price);
        $statement->bindParam(":description",$description);
        $statement->bindParam(":status",$size);

        date_default_timezone_set("Asia/Yangon");
        $date_now=date('Y-m-d H:m:s');
        $statement->bindParam(":created_date",$date_now);
        $statement->bindParam(":updated_date",$date_now);

       
        

        if($statement->execute()){
            return true;
        }
        else{
            return false;
        }

    }

    public function getParents(){
        $this->pdo=Database::connect();
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
        $sql='select * from categories where parent=0';
        $statement=$this->pdo->prepare($sql);
        $statement->execute();
        $categories=$statement->fetchAll(PDO::FETCH_ASSOC);
        return $categories;
    }

    public function editProducts($id){
        $this->pdo=Database::connect();
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
        $sql='select * from products where id=:id';
        $statement=$this->pdo->prepare($sql);
        $statement->bindParam(":id",$id);
        $statement->execute();
        $products=$statement->fetch(PDO::FETCH_ASSOC);
        return $products;
    }

    public function updateProduct($id,$type,$name,$filename,$price,$description,$status){
        $this->pdo=Database::connect();
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
        $sql='update products set name=:name,image=:image,price=:price,description=:description,status=:status where id=:id';
        $statement=$this->pdo->prepare($sql);
        $statement->bindParam(":id",$id);
       // $statement->bindParam(":type",$type);
        $statement->bindParam(":name",$name);
        $statement->bindParam(":image",$filename);
        $statement->bindParam(":price",$price);
        $statement->bindParam(":description",$description);
        $statement->bindParam(":status",$status);
       
       return $statement->execute();
    }

    public function deleteProducts($id){
        try{
            $this->pdo=Database::connect();
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
            $sql="delete from products where id=:id";
            $statement=$this->pdo->prepare($sql);
            $statement->bindparam(":id",$id);
            return $statement->execute();
           }
           catch(PDOException $e){
            return false;
           }
    }



    }


?>